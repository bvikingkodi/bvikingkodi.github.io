# -*- coding: utf-8 -*-
from modules.kodi_utils import get_property, set_property, clear_property, path_join, addon_profile, delete_file
userdata_path = addon_profile()

media_prop = 'fenlight.%s'

class LocalListsCache():
	def delete_memory_cache(self, string):
		clear_property(media_prop % string)

	def get_list(self, list_name):
		try:
			prop_string = media_prop % (list_name)
			cachedata = eval(get_property(prop_string))
		except: cachedata = None
		return cachedata
	
	def set_list(self, list_name, list):
		try:
			prop_string = media_prop % (list_name)
			set_property(prop_string, repr(list))
		except: pass
		return list
	
	def delete_list(self, list_name):
		try:
			delete_file(path_join(userdata_path, f'{list_name}.json'))
			self.set_list(list_name, [])
			return True
		except Exception:
			return False

	def delete_all_list_cache(self):
		try:
			self.delete_memory_cache('priorities')
			self.delete_memory_cache('blacklist')
			self.get_all_list_from_file()
			return True
		except Exception:
			return False

	def delete_list_cache(self, list_name):
		try:
			self.delete_memory_cache(list_name)
			self.get_list_from_file(list_name)
			return True
		except Exception:
			return False
		
	def get_all_list_from_file(self):
		self.get_list_from_file('priorities')
		self.get_list_from_file('blacklist')

	def get_list_from_file(self, list_name):
		self.set_list(list_name, self.retrieve_json(path_join(userdata_path, f'{list_name}.json')))

	def retrieve_json(self, path):
		from json import load
		file = []
		try:
			with open(path, 'r') as f:
				file = load(f)
		except FileNotFoundError: pass
		return file

local_lists_cache = LocalListsCache()