# -*- coding: utf-8 -*-
import json
from caches.base_cache import connect_database, get_timestamp
from modules.kodi_utils import clear_property, addon_profile
from time import time
userdata_path = addon_profile()

INSERT = 'INSERT OR REPLACE INTO cache (mediaflow_url, query_params, source_url, expires) VALUES (?, ?, ?, ?)'
UPDATE_SOURCES = 'UPDATE cache SET source_url=?, expires=? WHERE mediaflow_url=? AND query_params=?'
SELECT = 'SELECT source_url, expires FROM cache WHERE mediaflow_url=? AND query_params=?'
DELETE_ALL = 'DELETE FROM cache'
SINGLE_DELETE= 'DELETE FROM cache WHERE mediaflow_url=? AND query_params=?'
CLEAN = 'DELETE from cache WHERE CAST(expires AS INT) <= ?'

class MediaFlowCache():
	def set(self, mediaflow_url, query_params, source_url, expiration):
		try:
			dbcon = connect_database('mediaflow_db')
			expiration_time = self.get_timestamp(expiration) if expiration is not None else None
			dbcon.execute(INSERT, (mediaflow_url, query_params, source_url, expiration_time))
			return True
		except: return False
		
	def update_sources(self, mediaflow_url, query_params, source_url, expiration):
		try:
			dbcon = connect_database('mediaflow_db')
			expiration_time = self.get_timestamp(expiration) if expiration is not None else None
			dbcon.execute(UPDATE_SOURCES, (source_url, expiration_time, mediaflow_url, query_params))
			return True
		except:
			return False
		
	def get(self, mediaflow_url, query_params):
		result = None
		try:
			query_params = str(query_params)
			dbcon = connect_database('mediaflow_db')
			cache_data = dbcon.execute(SELECT, (mediaflow_url, query_params)).fetchone()
			if cache_data:
				if cache_data[1] is None or cache_data[1] > get_timestamp():
					result = cache_data[0]
				else:
					self.delete(mediaflow_url, query_params)
		except: pass
		return result
	
	def delete(self, mediaflow_url, query_params):
		try:
			dbcon = connect_database('mediaflow_db')
			dbcon.execute(SINGLE_DELETE, (mediaflow_url, query_params))
		except: return

	def clear_table(self):
		try:
			dbcon = connect_database('mediaflow_db')
			dbcon.execute(DELETE_ALL)
			dbcon.execute('VACUUM')
			return True
		except: return False
		
	def get_timestamp(self, offset=0):
		return int(time()) + (offset)
	
	def clean_database(self):
		try:
			dbcon = connect_database('mediaflow_db')
			dbcon.execute(CLEAN, (get_timestamp(),))
			dbcon.execute('VACUUM')
			dbcon.close()
			return True
		except: return False

mediaflow_cache = MediaFlowCache()