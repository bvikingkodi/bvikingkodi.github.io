import requests
from time import time
from json import dumps
from caches.settings_cache import get_setting
from urllib.parse import urlencode, urljoin, urlparse
from base64 import urlsafe_b64encode
from Cryptodome.Cipher import AES
from Cryptodome.Random import get_random_bytes
from Cryptodome.Util.Padding import pad
from modules.kodi_utils import get_property, set_property, osPath
from caches.mediaflow_cache import mediaflow_cache

supported_providers = {"real-debrid.com", "alldebrid.com", "premiumize.me", "easydebrid.com"}

class MediaflowAPI:
    def __init__(self):
        self.mediaflow_enabled = get_setting('fenlight.mediaflow.enabled') == 'true'
        self.mediaflow_url = get_setting('fenlight.mediaflow.url')
        self.mediaflow_password = get_setting('fenlight.mediaflow.password')

    def test_connection(self):
        response = None
        try:
            response = requests.head(self.generate_proxy_stream('https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf', test=True))
        except: pass
        return response
    
    def get_proxy_ip(self):
        if not self.mediaflow_enabled or not self.mediaflow_url:
            return None
        ip = get_setting('fenlight.mediaflow.ip') or get_property('mediaflow_ip')
        if not ip:
            try:
                ip = requests.get(self.encode_mediaflow_proxy_url("/proxy/ip")).json().get('ip')
                set_property('mediaflow_ip', ip)
            except:
                return None
        return ip

    def generate_proxy_stream(self, url, expiration=604800, test=False):
        if self.mediaflow_enabled and self.mediaflow_url:
            parsed_url = self.is_valid_url(url)
            if not parsed_url or (not test and not any(parsed_url.netloc.endswith(allowed) for allowed in supported_providers)):
                return url
            proxy_url = self.encode_mediaflow_proxy_url(
                "/proxy/stream",
                url,
                response_headers={
                    "Content-Disposition": "attachment, filename={}".format(
                        osPath.basename(url)
                    )
                },
                expiration=expiration,
            )
            return proxy_url
        return url
        
    def encode_mediaflow_proxy_url(
        self,
        endpoint = None,
        destination_url = None,
        query_params = {},
        request_headers = {},
        response_headers = {},
        expiration = 604800,
    ):
        query_params = query_params or {}
        if destination_url is not None:
            query_params["d"] = destination_url

        # Add headers if provided
        if request_headers:
            query_params.update(
                {f"h_{key}": value for key, value in request_headers.items()}
            )
        if response_headers:
            query_params.update(
                {f"r_{key}": value for key, value in response_headers.items()}
            )

        # Construct the full URL
        base_url = urljoin(self.mediaflow_url, endpoint)

        if self.mediaflow_password:
            if "api_password" not in query_params:
                query_params["api_password"] = self.mediaflow_password

            mediaflow_cache_params = urlencode(query_params)
            
            cache_link = self.check_mediaflow_cache(base_url, urlencode(query_params))
            if cache_link: return cache_link
            
            encrypted_token = self.encrypt_data(
                self.mediaflow_password, query_params, expiration
            )
            encoded_params = urlencode({"token": encrypted_token})
        else:
            encoded_params = urlencode(query_params)
            mediaflow_cache_params = encoded_params

            cache_link = self.check_mediaflow_cache(base_url, mediaflow_cache_params)
            if cache_link: return cache_link
        
        url = f"{base_url}?{encoded_params}"
        mediaflow_cache.set(base_url, mediaflow_cache_params, url, expiration)

        return url
    
    def encrypt_data(
        self, secret_key, data, expiration=None
    ):
        if expiration:
            data["exp"] = int(time()) + expiration
        ip = self.get_public_ip()
        if ip:
            data["ip"] = ip
        json_data = dumps(data).encode("utf-8")
        iv = get_random_bytes(16)
        cipher = AES.new(secret_key.encode("utf-8").ljust(32)[:32], AES.MODE_CBC, iv)
        encrypted_data = cipher.encrypt(pad(json_data, AES.block_size))
        return urlsafe_b64encode(iv + encrypted_data).decode("utf-8")
        
    def check_mediaflow_cache(self, base_url, query_params):
        cache_link = mediaflow_cache.get(base_url, query_params)
        if cache_link:
            if self.check_link(cache_link):
                return cache_link
        return None
        
    def check_link(self, url):
        try:
            response = requests.head(url, allow_redirects=True, timeout=5)
            return response.ok
        except requests.RequestException:
            return False
        
    def get_public_ip(self):
        try:
            public_ip = requests.get('https://api.ipify.org').text
            return public_ip
        except requests.RequestException:
            return None

    def is_valid_url(self, url):
        try:
            result = urlparse(url)
            if all([result.scheme, result.netloc]):
                return result
            else:
                return False
        except ValueError:
            return False
