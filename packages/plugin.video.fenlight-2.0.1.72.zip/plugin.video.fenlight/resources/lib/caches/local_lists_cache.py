# -*- coding: utf-8 -*-
import json
from caches.base_cache import connect_database
from modules.kodi_utils import clear_property

media_prop = 'fenlight.%s'
INSERT = 'INSERT OR REPLACE INTO {} (db_type, tmdb_id, sources, title) VALUES (?, ?, ?, ?)'
UPDATE_SOURCES = 'UPDATE {} SET sources=? WHERE db_type=? and tmdb_id=?'
DELETE = 'DELETE FROM {} where db_type=? and tmdb_id=?'
SELECT_ID = 'SELECT sources, title FROM {} WHERE db_type=? AND tmdb_id=?'
SELECT_ALL_IDS = 'SELECT db_type, tmdb_id FROM {}'
SELECT_ALL = 'SELECT db_type, tmdb_id, sources, title FROM {}'
SELECT_TYPE = 'SELECT db_type, tmdb_id, sources, title FROM {} WHERE db_type=?'
DELETE_ALL = 'DELETE FROM {}'
DELETE_TYPE = 'DELETE FROM {} WHERE db_type=?'

class LocalListsCache():
	def set(self, table, media_type, tmdb_id, sources, title):
		try:
			dbcon = connect_database('local_lists_db')
			dbcon.execute(INSERT.format(table), (media_type, str(tmdb_id), json.dumps(sources['sources']), title))
			return True
		except: return False

	def update_sources(self, table, media_type, tmdb_id, sources):
		try:
			if not sources:
				return self.delete(table, media_type, tmdb_id)
			else:
				dbcon = connect_database('local_lists_db')
				dbcon.execute(UPDATE_SOURCES.format(table), (json.dumps(sources), media_type, str(tmdb_id)))
			return True
		except: return False

	def delete(self, table, media_type, tmdb_id):
		try:
			dbcon = connect_database('local_lists_db')
			dbcon.execute(DELETE.format(table), (media_type, str(tmdb_id)))
			return True
		except: return False

	def get_property_id(self, table, media_type, tmdb_id):
		return table + '-' + media_type + '_' + str(tmdb_id)

	def get_id(self, table, media_type, tmdb_id):
		dbcon = connect_database('local_lists_db')
		result = dbcon.execute(SELECT_ID.format(table), (media_type, str(tmdb_id))).fetchone()
		if result:
			return {'title': result[1], 'sources': json.loads(result[0])}
		return {}
	
	def get_all(self, table):
		dbcon = connect_database('local_lists_db')
		return {f"{str(i[0])}_{str(i[1])}": {'title': str(i[3]),'sources': json.loads(i[2])} for i in dbcon.execute(SELECT_ALL.format(table)).fetchall()}

	def get_type(self, table, media_type):
		dbcon = connect_database('local_lists_db')
		return {f"{str(i[0])}_{str(i[1])}": {'title': str(i[3]),'sources': json.loads(i[2])} for i in dbcon.execute(SELECT_TYPE.format(table), (media_type,)).fetchall()}

	def clear_all(self):
		return self.clear_table('priorities') and self.clear_table('blacklist')

	def clear_table(self, table):
		try:
			dbcon = connect_database('local_lists_db')
			dbcon.execute(DELETE_ALL.format(table))
			dbcon.execute('VACUUM')
			return True
		except: return False

	def clear_type(self, table, media_type):
		try:
			dbcon = connect_database('local_lists_db')
			dbcon.execute(DELETE_TYPE.format(table), (media_type,))
			dbcon.execute('VACUUM')
			return True
		except: return False

	def delete_memory_cache(self, string):
		clear_property(media_prop % string)

local_lists_cache = LocalListsCache()