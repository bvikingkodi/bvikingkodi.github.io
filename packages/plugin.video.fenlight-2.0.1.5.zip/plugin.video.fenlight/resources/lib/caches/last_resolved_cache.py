# -*- coding: utf-8 -*-
from caches.base_cache import connect_database, get_timestamp

GET_ALL = 'SELECT db_type, tmdb_id FROM resolved'
SELECT_RESULTS = 'SELECT source, expires FROM resolved WHERE db_type = ? AND tmdb_id = ?'
DELETE_RESULTS = 'DELETE FROM resolved WHERE db_type = ? AND tmdb_id = ?'
INSERT_RESULTS = 'INSERT OR REPLACE INTO resolved (db_type, tmdb_id, source, expires) VALUES (?, ?, ?, ?)'
SINGLE_DELETE = 'DELETE FROM resolved WHERE db_type=? AND tmdb_id=?'
FULL_DELETE = 'DELETE FROM resolved'
CLEAN = 'DELETE from resolved WHERE CAST(expires AS INT) <= ?'

class LastResolvedCache():
	def get(self, media_type, tmdb_id):
		result = None
		try:
			cache_data = self._execute(SELECT_RESULTS, (media_type, tmdb_id)).fetchone()
			if cache_data:
				if cache_data[1] > get_timestamp(): result = eval(cache_data[0])
				else: self.delete(media_type, tmdb_id)
		except: pass
		return result

	def set(self, media_type, tmdb_id, source, expire_time):
		try:
			expires = get_timestamp(expire_time)
			self._execute(INSERT_RESULTS, (media_type, tmdb_id, repr(source or []), int(expires)))
		except: pass

	def delete(self, media_type, tmdb_id):
		try:
			self._execute(DELETE_RESULTS, (media_type, tmdb_id))
		except: return

	def delete_cache_single(self, media_type, tmdb_id):
		try:
			self._execute(SINGLE_DELETE, (media_type, tmdb_id))
			self._vacuum()
			return True
		except: return False

	def clear_cache(self):
		try:
			self._execute(FULL_DELETE, ())
			self._vacuum()
			return True
		except: return False

	def _execute(self, command, params):
		self.dbcon = connect_database('last_resolved_db')
		return self.dbcon.execute(command, params)

	def clean_database(self):
		try:
			dbcon = connect_database('last_resolved_db')
			dbcon.execute(CLEAN, (get_timestamp(),))
			dbcon.close()
			self._vacuum()
			return True
		except: return False

	def _vacuum(self):
		dbcon = connect_database('last_resolved_db')
		dbcon.execute('VACUUM')
		dbcon.close()

last_resolved_cache = LastResolvedCache()
